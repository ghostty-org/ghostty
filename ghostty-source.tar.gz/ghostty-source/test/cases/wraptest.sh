function test_do {
  xdotool type "wraptest"
  xdotool key Return
}
