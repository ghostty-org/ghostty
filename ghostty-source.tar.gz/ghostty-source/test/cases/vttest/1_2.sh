function test_do {
  xdotool type "vttest"
  xdotool key Return
  sleep 1
  xdotool type "1"
  xdotool key Return
  sleep 0.5
  xdotool key Return
}
