function test_do {
  xdotool type "vttest"
  xdotool key Return
}
