---
name: Pre-Discussed and Approved Topics
about: |-
  Only for topics already discussed and approved in the GitHub Discussions section.
---

**DO NOT OPEN A NEW ISSUE. PLEASE USE THE DISCUSSIONS SECTION.**

**I DIDN'T READ THE ABOVE LINE. PLEASE CLOSE THIS ISSUE.**
