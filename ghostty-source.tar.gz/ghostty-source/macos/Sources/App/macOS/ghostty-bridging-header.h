// C imports here are exposed to Swift.

#import "VibrantLayer.h"
