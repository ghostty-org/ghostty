enum AppError: Error {
  case surfaceCreateError
}
