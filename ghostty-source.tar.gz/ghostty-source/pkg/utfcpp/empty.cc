// Needed for Zig build to be happy
void ghostty_utfcpp_stub() {}
